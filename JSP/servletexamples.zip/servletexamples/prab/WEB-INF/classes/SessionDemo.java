import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SessionDemo extends HttpServlet
{

    public void doGet(HttpServletRequest req,HttpServletResponse res)
	throws ServletException, IOException
	{
		PrintWriter out = res.getWriter();

		// get session object
		HttpSession session = req.getSession(true);

        // print session info
		Date created = new Date(session.getCreationTime());
        Date accessed = new Date(session.getLastAccessedTime());

        out.println("<br>ID " + session.getId());
        out.println("<br>Created: " + created);
        out.println("<br>Last Accessed: " + accessed);

        // set session info if needed
        String dataName = req.getParameter("dataName");
        if (dataName != null && dataName.length() > 0)
        {
            String dataValue = req.getParameter("dataValue");
            session.putValue(dataName, dataValue);
        }

        // print session contents

        String[] valueNames = session.getValueNames();
        if (valueNames != null &&  valueNames.length > 0)
        {
            for (int i = 0; i < valueNames.length; i++)
            {
                String name = valueNames[i];
                String value = session.getValue(name).toString();
                out.println("<br>" + name + " = " + value);
            }
        }
    }
}
