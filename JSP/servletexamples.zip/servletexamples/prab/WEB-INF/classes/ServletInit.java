import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *Example using servlet initialization.
 */

public class ServletInit extends HttpServlet
{
	String dbiUrl, dbUrl;

	public void init(ServletConfig config) throws ServletException
	{
		// Always call super.init
		super.init(config);
		dbiUrl = config.getInitParameter("dbi");
		dbUrl = config.getInitParameter("db");
    }


	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{
    	response.setContentType("text/html");
    	PrintWriter out = response.getWriter();
    	String title = "Initialization Example 2";
    	out.println("<HTML><HEAD>");
    	out.println("<TITLE>"+title+"</TITLE></HEAD>");
    	out.println("<BODY><H1>Links to Sites</H1>");
    	out.println("<TABLE><TR><TH>Course");
    	out.println("</TH><TH>Link</TH></TR>");
    	out.println("<TR><TD>Hotmail</TD><TD>" + dbiUrl + "</TD></TR>");
    	out.println("<TR><TD>Yahoo</TD><TD>" + dbUrl + "</TD></TR>");
    	out.println("</TABLE></BODY></HTML>");
  }
}
