import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

//Request Information

public class Servlet5 extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body>");
        out.println("<head>");
        out.println("<title>Request Information Example</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h3>Request Information Example</h3>");
        out.println("<br>Method: " + request.getMethod());
        out.println("<br>Request URI: " + request.getRequestURI());
        out.println("<br>Protocol: " + request.getProtocol());
        out.println("<br>PathInfo: " + request.getPathInfo());
        out.println("<br>Remote Address: " + request.getRemoteAddr());
        out.println("</body>");
        out.println("</html>");
    }

    /**
     * We are going to perform the same operations for POST requests
     * as for GET methods, so this method just sends the request to
     * the doGet method.
     */

    public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
    {
        doGet(request, response);
    }
}
