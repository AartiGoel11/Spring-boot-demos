import java.io.*;				//libraries for i/o
import javax.servlet.*;			//GenericServlet
import javax.servlet.http.*;	//HttpServlet
import java.util.*;				// date

public class ServletTime extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{

		Date dt = new Date();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<HTML><BODY>");
		out.println("<H2>Welcome to my servlet page.</H2>");
		out.println("<P>Time: "+ dt +"</P>");
		out.println("</BODY></HTML>");
	}
}
