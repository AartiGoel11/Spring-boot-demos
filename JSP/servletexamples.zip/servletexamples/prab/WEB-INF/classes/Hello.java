// simple Java Servlet showing Hello World with hit counter

import java.io.*;
import javax.servlet.http.*;

public class Hello extends HttpServlet
{
  private int hitCounter = 0;  // servlets stay alive for many requests!

  public void doGet( HttpServletRequest req, HttpServletResponse res )
    throws IOException
  {
    res.setContentType( "text/html" );

    PrintWriter toClient = res.getWriter();

    ++hitCounter;

    toClient.println( "<title>My First Servlet</title>" );
    toClient.println( "<h1>Hello World</h1>" );
    toClient.println( "<p>This was hit #" + hitCounter + "</p>" );
    
    toClient.close();
  }
}


