import java.io.*;
import java.util.Enumeration;

import javax.servlet.*;
import javax.servlet.http.*;


/**
 * This is a simple example of an HTTP Servlet that uses the HttpSession
 * class
 *
 * Note that in order to guarantee that session response headers are
 * set correctly, the session must be retrieved before any output is
 * sent to the client.
 */
public class SessionServlet extends HttpServlet { 

    public void doGet (HttpServletRequest req, HttpServletResponse res)
      throws ServletException, IOException
      {
	  
	  //Get the session object
	  HttpSession session = req.getSession(true);
	  
	  //Get the output stream
	  ServletOutputStream out = res.getOutputStream();
	  
	  res.setContentType("text/html");
	  
	  out.println("<HEAD><TITLE> SessionServlet Output " +
		      "</TITLE></HEAD><BODY>");
	  out.println("<h1> SessionServlet Output </h1>");

	  //Here's the meat
	  Integer ival = (Integer) session.getValue("sessiontest.counter");
	  if (ival==null) ival = new Integer(1);
	  else ival = new Integer(ival.intValue() + 1);
	  session.putValue("sessiontest.counter", ival);

	  out.println("You have hit this page <b>" + ival + "</b> times.<p>");

	  // encodeURLeEncodes the specified URL by including the session ID in it 
	  // if cookies are not turned on or not supported by the browser
	  out.println("Click <a href=" + res.encodeURL("/session.html") + 
		      ">here</a>");
	  out.println(" to ensure that session tracking is working even if" +
		      " cookies aren't supported.<br>");
	  out.println(" Note that by default URL rewriting is not enabled due" +
		      " to it's expensive overhead.");
	  out.println("<p>");
	  
	  out.println("<h3>Request and Session Data:</h3>");
	  out.println("Session ID in Request: " + req.getRequestedSessionId());
	  out.println("<br>Session ID in Request from Cookie: " + 
					req.isRequestedSessionIdFromCookie());
	  out.println("<br>Session ID in Request from URL: " + 
					req.isRequestedSessionIdFromURL());
	  out.println("<br>Valid Session ID: " + 
					req.isRequestedSessionIdValid());
	  out.println("<h3>Session Data:</h3>");
	  out.println("New Session: " + session.isNew());
	  out.println("<br>Session ID: " + session.getId());
	  out.println("<br>Creation Time: " + session.getCreationTime());
	  out.println("<br>Last Accessed Time: " + 
						session.getLastAccessedTime());
	  out.println("<br><a href=\"/examples/simple_servlets\">Up</a>");
	  out.println("</BODY>");
	  out.close();
      }
    
    public String getServletInfo() {
        return "A simple session servlet";
    }
}
