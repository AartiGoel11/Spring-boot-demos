import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Servlet3 extends HttpServlet {

    static Connection conn;
	static Statement stmt;
	ResultSet rs = null;

    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

		out.println("<html>");
		out.println("<head>");
		out.println("<title>Hello World!</title>");
		out.println("</head>");
		out.println("<body>");

		int rollno = Integer.parseInt(request.getParameter("rollno"));

		String sname=" ";
		int marks1=0, marks2=0, age=0, total=0;
		int flag=0;

		try{


       	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		conn = DriverManager.getConnection("jdbc:odbc:prab","admin","");
		stmt=conn.createStatement();

		String s = "select * from marks";
		rs = stmt.executeQuery(s);

		while (rs.next())
		{
			int rno = rs.getInt("rollno");

			if(rollno == rno)
			{
				sname = rs.getString("name");
				age = rs.getInt("age");
				marks1 = rs.getInt("marks1");
				marks2 = rs.getInt("marks2");
				total = marks1+marks2;
				flag=1;
				break;
			}
		}

		}catch(Exception e){}

		if (flag==1)
		{
			out.println("<h1>Marks are:</h1>");
        	out.println("<table border=2 cellpadding=10 cellspacing=10 width=50% align=center>");
        	out.println("<tr bgcolor=red><td>Roll No</td><td>" + rollno + "</td></tr>");
        	out.println("<tr><td>Name</td><td>" + sname + "</td></tr>");
        	out.println("<tr><td>Age</td><td>" + age + "</td></tr>");
        	out.println("<tr><td>Marks1</td><td>" + marks1 + "</td></tr>");
        	out.println("<tr><td>Marks2</td><td>" + marks2 + "</td></tr>");
        	out.println("<tr><td>Total</td><td>" + total + "</td></tr>");
			out.println("</table>");
		}
		else
			out.println("<h1>Roll Number not exisiting</h1>");


			out.println("<a href=index1.htm>Return to Home Page</a>" + "<br>");
			out.println("</body>");
        	out.println("</html>");


    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws IOException, ServletException
	{
		doGet(request, response);
	}

}