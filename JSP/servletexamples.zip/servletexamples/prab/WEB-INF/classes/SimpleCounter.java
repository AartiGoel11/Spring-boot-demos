import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/**
 * A very simple text counter.
 */
public class SimpleCounter extends HttpServlet {
  /**
   * Initialize the counter to 0.
   */
  public void init(ServletConfig config) throws ServletException {
    super.init(config);
    count = 0;
  }
  /**
   * A get request will simply be passed to the post method.
   */
  public void doGet(HttpServletRequest request, HttpServletResponse response)
     throws ServletException, IOException {
    doPost( request, response );
  }
  /**
   * Prints the current count to the servlet client.
   */
  public void doPost(HttpServletRequest request, HttpServletResponse response)
     throws ServletException, IOException {
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    out.println(getCurrentCount());
    out.close();
  }
  /**
   * Increments the count value and returns the result.
   */
  private synchronized int getCurrentCount() {
    count++;
    return count;
  }
  private int count;
}

