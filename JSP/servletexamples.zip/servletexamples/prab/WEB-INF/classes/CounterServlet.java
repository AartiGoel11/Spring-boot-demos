import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CounterServlet extends HttpServlet
{
	private File _counterFile = new File ("/tmp/CounterServlet.dat");
	private CounterWriterThread _cntWrtThread = new CounterWriterThread ();
	private int _cnt = 0;
	private boolean _fTerminating = false;

	public void init (ServletConfig config) throws ServletException
	{
		super.init (config);
		readCounter ();
		_cntWrtThread.start ();
	}

	public class CounterWriterThread extends Thread
	{
		public void run ()
		{
			while (!_fTerminating)
			{
				writeCounter ();
				try
				{
					sleep (1000);
				}
				catch (Exception ie) { }
			}
		}
	}

	private void writeCounter ()
	{
		DataOutputStream dos = null;
		try
		{
			dos = new DataOutputStream (new FileOutputStream (_counterFile));
			dos.writeInt (_cnt);
		} catch (Exception e){}
		finally
		{
			try
			{
				if (dos != null)
					dos.close ();
			}
			catch (Exception ioe){}
		}
	}

	private void readCounter ()
	{
		DataInputStream dis = null;
		try
		{
			dis = new DataInputStream (new FileInputStream (_counterFile));
			_cnt = dis.readInt ();
		}catch (Exception e){}
		finally
		{
			try
			{
				if (dis != null)
					dis.close ();
			}
			catch (Exception ioe){}
	}


	public void doGet (HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{
		PrintWriter  out;    // set content type and other response header fields first
		response.setContentType("text/html");        // then write the data of the response
		out = response.getWriter ();
		_cnt++;
		Cookie cookies[] = request.getCookies();
		Integer nof = new Integer (0);
		for(int i = 0; i < cookies.length; i++ )
		{
			if (cookies[i].getName ().equals ("CounterServletCookie"))
			{
				String nofS = cookies[i].getValue ();
				try
				{
					nof = Integer.valueOf (nofS);
				}catch (Exception nfe){}

				break;
			}
		}

		nof = new Integer (nof.intValue () + 1);
		Cookie c = new Cookie ("CounterServletCookie", nof.toString ());
		c.setMaxAge (3600 * 24 * 365);
		c.setPath   ("/");
		response.addCookie (c);
		out.println("<HTML><BODY><CENTER>");

		if (nof.intValue () > 1)
			out.println ("Thank you for coming back. You have visited this page <B>" + nof + "</b> times");
			out.println("This page was accessed <B>" + _cnt + "</B> times total");
			out.println("</CENTER></BODY></HTML>");
		}
	}
}
