import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Servlet2 extends HttpServlet {

    static Connection conn;
	static Statement stmt;

    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        int rollno = Integer.parseInt(request.getParameter("rollno"));
        String sname = request.getParameter("name");
        int age = Integer.parseInt(request.getParameter("age"));
        int marks1 = Integer.parseInt(request.getParameter("marks1"));
        int marks2 = Integer.parseInt(request.getParameter("marks2"));

        out.println("<html>");
        out.println("<head>");
        out.println("<title>Hello World!</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Values being saved: </h1><br>");
        out.println("<font size=4 color=red>");
        out.println("Roll No: " + rollno + "<br>");
        out.println("Name   : " + sname + "<br>");
        out.println("Age    : " + age + "<br>");
        out.println("Marks1 : " + marks1 + "<br>");
        out.println("Marks2 : " + marks2 + "<br>");

		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			conn = DriverManager.getConnection("jdbc:odbc:prab","admin","");
			stmt=conn.createStatement();
			String s = "insert into marks (rollno, name, age, marks1, marks2) values (" + rollno + ",'" + sname + "'" + "," + age + "," + marks1 + "," + marks2 + ")";
			// out.println("SQL Statement: " + s + "<br>");
			stmt.executeUpdate(s);
			out.println("Record Inserted !!" + "<br>");
		}
		catch(Exception e)
		{}

		out.println("<a href=index1.htm>Return to Home Page</a>" + "<br>");
		out.println("</font>");
		out.println("</body>");
        out.println("</html>");


    }
}