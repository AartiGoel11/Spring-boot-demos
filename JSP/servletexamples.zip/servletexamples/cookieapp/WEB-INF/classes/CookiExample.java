import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class CookiExample extends HttpServlet
{
	static int i=1;
	static int j=2;
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();

		String shirt=req.getParameter("shirt");
		String book=req.getParameter("book");
		Cookie c1=new Cookie("shirt"+i,shirt);
		Cookie c2=new Cookie("book"+i,book);

		res.addCookie(c1);
		res.addCookie(c2);
		i++;
		j++;

		out.println("<h3>Items in the shopping cart are:</h3>");
		out.println("<h3>"+c1.getName()+": "+shirt+"</h3>");
		out.println("<h3>"+c2.getName()+": "+book+"</h3>");

		Cookie c[]=req.getCookies();
		if(c!=null)
		{
			for(int k=0;k<c.length;k++)
				out.println("<h3>"+c[k].getName()+" : "+c[k].getValue()+"</h3>");
		}

		RequestDispatcher rd=req.getRequestDispatcher("/shop.html");
		rd.include(req,res);
		out.close();
	}
}
		