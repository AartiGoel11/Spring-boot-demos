import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class GrossServlet extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
	{
		float basic=Float.parseFloat(req.getParameter("basic"));
		float da=0.5f*basic;
		float hra=0.4f*basic;
		float gross=basic+da+hra;
		Float f=new Float(gross);
		req.setAttribute("gross",f);
		ServletContext sc=getServletContext();
		RequestDispatcher rd=sc.getRequestDispatcher("/net");
		rd.forward(req,res);
	}
}