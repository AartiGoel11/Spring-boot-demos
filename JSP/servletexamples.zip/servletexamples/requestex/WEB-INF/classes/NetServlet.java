import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class NetServlet extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		Float gross=(Float)req.getAttribute("gross");
		float net=gross.floatValue()-2000-1000;
		getServletContext().getRequestDispatcher("/caption.html").include(req,res);
		out.println("<html>");
		out.println("<body bgcolor=cyan>");
		out.println("Your net salary is:"+net);
		out.println("</body>");
		out.println("</html>");
		out.close();
	}
}