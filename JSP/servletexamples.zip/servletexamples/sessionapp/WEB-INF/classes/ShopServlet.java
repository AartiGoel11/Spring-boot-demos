import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class ShopServlet extends HttpServlet
{
	HttpSession session;
	String pCode,qty,clickButton;
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();

		session=req.getSession(true);
		clickButton=req.getParameter("submit");
		if(clickButton.equals("Add Item"))
		{
			pCode=req.getParameter("pcode");
			qty=req.getParameter("qty");
			if(!pCode.equals("")||qty.equals(""))
				session.setAttribute(pCode,qty);
				res.sendRedirect("./shop.html");
		}
		else if(clickButton.equals("Remove Item"))
		{
			pCode=req.getParameter("pcode");
			session.removeAttribute(pCode);
			res.sendRedirect("./shop.html");
		}
		else if(clickButton.equals("Show Items"))
		{
			Enumeration e=session.getAttributeNames();
			if(e.hasMoreElements())
			{
				out.println("<h2><font color=blue>Your Shopping Cart Items</font></h2>");
				while(e.hasMoreElements())
				{
					out.println("<body bgcolor=cyan>");
					String code=(String)e.nextElement();
					out.println("<h2>Product Code: "+code);
					out.println("Quantity :" +session.getAttribute(code)+"</h2>");
				}
			}
			else{
				out.println("<body bgcolor=cyan>");
				out.println("<h2><font color=red>No Items Please</font></h2>");
			}
		}
		else if(clickButton.equals("Logout"))
		{
			session.invalidate();
			res.sendRedirect("./shop.html");
		}
		else if(clickButton.equals("Pay Amount"))
		{
			out.println("<body bgcolor=yellow>");
			out.println("<h2><font color=red>Payment logic goes here</font></h2>");
		}
		out.close();
	}
}
